package MainJava;
	import java.util.ArrayList;
	import java.util.HashSet;
	import java.util.Scanner;

	//Eliminar elementos duplicados en un ArrayList
	public class Arraylist6 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Ingresa números (escribe un número negativo para terminar):");
	        while (true) {
	            int numero = scanner.nextInt();
	            if (numero < 0) {
	                break;
	            }
	            numeros.add(numero);
	        }

	        HashSet<Integer> sinDuplicados = new HashSet<>(numeros);
	        System.out.println("Lista sin duplicados: " + sinDuplicados);
	    }
	}


