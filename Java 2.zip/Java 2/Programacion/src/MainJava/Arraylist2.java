package MainJava;
	import java.util.ArrayList;
	import java.util.Scanner;

	// Operaciones básicas con ArrayList
	public class Arraylist2 {
	    public static void main(String[] args) {
	        ArrayList<String> nombres = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.print("Ingresa un nombre (o 'fin' para terminar): ");
	            String nombre = scanner.nextLine();
	            if (nombre.equals("fin")) {
	                break;
	            }
	            nombres.add(nombre);
	        }

	        System.out.println("Nombres ingresados: " + nombres);

	        System.out.print("Ingresa un nombre para eliminar: ");
	        String eliminar = scanner.nextLine();
	        if (nombres.remove(eliminar)) {
	            System.out.println("Nombre eliminado.");
	        } else {
	            System.out.println("El nombre no se encontró.");
	        }

	        System.out.println("Lista actualizada: " + nombres);
	    }
	}

