package MainJava;
	import java.util.ArrayList;
	import java.util.Random;
	
	//Conversión de ArrayList a Array
	public class Arraylist7 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Random random = new Random();

	        for (int i = 0; i < 10; i++) {
	            numeros.add(random.nextInt(100) + 1);
	        }

	        Integer[] array = new Integer[numeros.size()];
	        array = numeros.toArray(array);

	        System.out.print("Array generado: ");
	        for (int num : array) {
	            System.out.print(num + " ");
	        }
	    }
	}


