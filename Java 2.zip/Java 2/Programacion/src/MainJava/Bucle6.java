package MainJava;
import java.util.Scanner;
public class Bucle6 {
	//6. Número de dígitos de un número
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Ingresa un número entero: ");
	        int numero = scanner.nextInt();
	        int contador = 0;

	        while (numero != 0) {
	            numero /= 10;
	            contador++;
	        }

	        System.out.println("El número tiene " + contador + " dígitos.");
	    }
}
