package MainJava;

public class Array1 {

	public static void main (String[] args) {
		
        //1. declaracion y inicializacion

    int [] numeros = {1,2,3,4,5,6,7,8,9,10};

for (int element : numeros) {
	System.out.println(element);
}
}
}
