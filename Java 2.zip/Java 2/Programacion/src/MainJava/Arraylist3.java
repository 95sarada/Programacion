package MainJava;

	import java.util.ArrayList;
	import java.util.Scanner;
	
	//Buscar en un ArrayList
	public class Arraylist3 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        for (int i = 0; i < 10; i++) {
	            System.out.print("Ingresa un número: ");
	            numeros.add(scanner.nextInt());
	        }

	        System.out.print("Ingresa el número a buscar: ");
	        int buscar = scanner.nextInt();

	        if (numeros.contains(buscar)) {
	            System.out.println("El número " + buscar + " se encuentra en el índice: " + numeros.indexOf(buscar));
	        } else {
	            System.out.println("El número no está presente en la lista.");
	        }
	    }
	}


