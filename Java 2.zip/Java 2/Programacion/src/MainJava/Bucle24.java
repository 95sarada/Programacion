package MainJava;

//5. Suma de los Números del 1 al 100
public class Bucle24 {
	public static void main(String[] args) {
        int suma = 0;

        for (int i = 1; i <= 100; i++) {
            suma += i;
        }

        System.out.println("La suma de los números del 1 al 100 es: " + suma);
    }
}
