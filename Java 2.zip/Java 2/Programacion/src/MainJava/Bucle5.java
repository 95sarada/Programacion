package MainJava;
import java.util.Scanner;
public class Bucle5 {
	//5. Tabla de multiplicar
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Ingresa un número entero: ");
	        int numero = scanner.nextInt();

	        for (int i = 1; i <= 10; i++) {
	            System.out.println(numero + " x " + i + " = " + (numero * i));
	        }
	    }
}
