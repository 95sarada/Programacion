package MainJava;

public class Array2 {
public static void main (String[] args) {
	
	 // 2. suma de los elementos
	
		    int [] numeros = {1, 2, 3, 4, 5};
		int suma = 0;
		for (int element : numeros) {
			suma += element;
		}
		System.out.println("La suma de los numeros es:" + suma);
		
		   
		
}
}
