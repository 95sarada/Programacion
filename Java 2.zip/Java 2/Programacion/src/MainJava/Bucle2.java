package MainJava;

	//2. Suma de los primeros N números
	import java.util.Scanner;

	public class Bucle2 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Ingresa un número entero positivo N: ");
	        int N = scanner.nextInt();
	        int suma = 0;

	        for (int i = 1; i <= N; i++) {
	            suma += i;
	        }

	        System.out.println("La suma de los primeros " + N + " números naturales es: " + suma);
	    }
	}


