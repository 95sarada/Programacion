package MainJava;
import java.util.HashMap;
public class Hashmap1 {
    public static void main(String[] args) {

        // Crear el objeto HashMap llamado capitalcities
        HashMap<String, String> capitalcities = new HashMap<>();

        // Agregar claves y valores (país, ciudad)
        capitalcities.put("England", "London");
        capitalcities.put("Spain", "Madrid");
        capitalcities.put("France", "Paris");
        capitalcities.put("USA", "Washington DC");

        // Imprimir el HashMap
        System.out.println(capitalcities);

        // Para acceder a un elemento en el HashMap, usar get
        System.out.println(capitalcities.get("England"));

        // Para eliminar un elemento en el HashMap, usar remove
        capitalcities.remove("Spain");

        // Para eliminar todos los elementos en el HashMap, usar clear
        capitalcities.clear();

        // Para saber cuántos elementos hay, usar size
        System.out.println(capitalcities.size());
    }
}

