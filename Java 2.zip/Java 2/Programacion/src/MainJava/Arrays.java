package MainJava;

public class Arrays {
public static void main (String[] args) {
	
	        //1. declaracion y inicializacion
	
	/*    int [] numeros = {1,2,3,4,5,6,7,8,9,10};
	
	for (int element : numeros) {
		System.out.println(element);
	}
	    */
	
	       // 2. suma de elementos
	
	/*    int [] numeros = {1, 2, 3, 4, 5};
	int suma = 0;
	for (int element : numeros) {
		suma += element;
	}
	System.out.println("La suma de los numeros es:" + suma);
	
	   */
	
	
	        
	
	   
	
	
	
	
	
}
}
