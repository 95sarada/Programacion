package MainJava;

	import java.util.ArrayList;
	import java.util.Scanner;

	//Actualización de elementos en ArrayList
public class Arraylist4 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        for (int i = 0; i < 10; i++) {
	            numeros.add(i + 1);
	        }

	        while (true) {
	            System.out.println("Lista actual: " + numeros);
	            System.out.print("Ingresa el índice (0-9) para actualizar el valor: ");
	            int indice = scanner.nextInt();
	            if (indice < 0 || indice >= 10) {
	                System.out.println("Índice fuera de rango.");
	                break;
	            }
	            System.out.print("Ingresa el nuevo valor para el índice " + indice + ": ");
	            int valor = scanner.nextInt();
	            numeros.set(indice, valor);
	        }
	    }
	}


