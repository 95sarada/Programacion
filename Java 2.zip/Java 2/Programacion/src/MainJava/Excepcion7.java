package MainJava;
	class EdadInvalidaException extends Exception {
	    public EdadInvalidaException(String mensaje) {
	        super(mensaje);
	    }
	}

	
	class Persona {
	    private String nombre;
	    private int edad;

	    public Persona(String nombre) {
	        this.nombre = nombre;
	    }

	    public void establecerEdad(int edad) throws EdadInvalidaException {
	        if (edad < 0) {
	            throw new EdadInvalidaException("La edad no puede ser negativa.");
	        }
	        this.edad = edad;
	    }

	    public String getNombre() {
	        return nombre;
	    }

	    public int getEdad() {
	        return edad;
	    }
	}

	
	public class Excepcion7 {
	    public static void main(String[] args) {
	        Persona persona = new Persona("Juan");
	        try {
	            persona.establecerEdad(-5); 
	        } catch (EdadInvalidaException e) {
	            System.out.println("Error: " + e.getMessage());
	        }

	        try {
	            persona.establecerEdad(25); 
	            System.out.println("Edad de " + persona.getNombre() + ": " + persona.getEdad());
	        } catch (EdadInvalidaException e) {
	            System.out.println("Error: " + e.getMessage());
	        }
	    }
	}


