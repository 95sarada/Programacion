package MainJava;

public class Matriz2 {
	//Encontrar la fila con la suma más alta
	
	    public static void main(String[] args) {
	        int[][] matriz = {
	            {1, 2, 3},
	            {4, 5, 6},
	            {7, 8, 9}
	        };

	        int filaConMayorSuma = 0;
	        int mayorSuma = 0;

	        for (int i = 0; i < matriz.length; i++) {
	            int sumaFila = 0;
	            for (int j = 0; j < matriz[i].length; j++) {
	                sumaFila += matriz[i][j];
	            }
	            if (sumaFila > mayorSuma) {
	                mayorSuma = sumaFila;
	                filaConMayorSuma = i;
	            }
	        }

	        System.out.println("El índice de la fila con la mayor suma es: " + filaConMayorSuma);
	    }
	}


