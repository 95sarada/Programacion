package MainJava;
import java.util.Scanner;

//15. Promedio de una serie de números
public class Bucle15 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa la cantidad de números N: ");
        int N = scanner.nextInt();
        int suma = 0;

        for (int i = 0; i < N; i++) {
            System.out.print("Ingresa el número " + (i + 1) + ": ");
            suma += scanner.nextInt();
        }

        double promedio = (double) suma / N;
        System.out.println("El promedio es: " + promedio);
    }
}
