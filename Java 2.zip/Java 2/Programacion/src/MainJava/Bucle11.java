package MainJava;
import java.util.Scanner;

public class Bucle11 {
	
	//10. Serie de Fibonacci
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa el valor de N: ");
        int N = scanner.nextInt();

        int a = 0, b = 1;

        for (int i = 0; i < N; i++) {
            System.out.print(a + " ");
            int temp = a;
            a = b;
            b = temp + b;
        }
    }
}
