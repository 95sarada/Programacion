package MainJava;

public class Hashmap4 {

	import java.util.HashMap;
	import java.util.Map;

	    public static Map<String, Map<String, String>> crearDiccionario() {
	        Map<String, Map<String, String>> diccionario = new HashMap<>();

	        Map<String, String> traduccionesHola = new HashMap<>();
	        traduccionesHola.put("es", "Hola");
	        traduccionesHola.put("en", "Hello");
	        traduccionesHola.put("fr", "Bonjour");
	        traduccionesHola.put("de", "Hallo");

	        Map<String, String> traduccionesAdios = new HashMap<>();
	        traduccionesAdios.put("es", "Adiós");
	        traduccionesAdios.put("en", "Goodbye");
	        traduccionesAdios.put("fr", "Au revoir");
	        traduccionesAdios.put("de", "Auf Wiedersehen");

	        
	        diccionario.put("Hola", traduccionesHola);
	        diccionario.put("Adiós", traduccionesAdios);

	        return diccionario;
	    }

	    public static String obtenerTraduccion(Map<String, Map<String, String>> diccionario, String palabra, String idioma) {
	        if (diccionario.containsKey(palabra)) {
	            Map<String, String> traducciones = diccionario.get(palabra);
	            return traducciones.getOrDefault(idioma, "Traducción no encontrada");
	        }
	        return "Palabra no encontrada en el diccionario";
	    }

	    public static void main(String[] args) {
	       
	        Map<String, Map<String, String>> diccionario = crearDiccionario();

	        System.out.println("Traducción de 'Hola' al inglés: " + obtenerTraduccion(diccionario, "Hola", "en"));
	        System.out.println("Traducción de 'Adiós' al francés: " + obtenerTraduccion(diccionario, "Adiós", "fr"));
	        System.out.println("Traducción de 'Hola' al alemán: " + obtenerTraduccion(diccionario, "Hola", "de"));
	        System.out.println("Traducción de 'Adiós' al italiano: " + obtenerTraduccion(diccionario, "Adiós", "it"));
	        {
	}

}
