package MainJava;
import java.util.Scanner;
public class Bucles {
public static void main(String[] args) {
	
	/*
	String name = "Jack Parker";
	System.out.println(name.toLowerCase());

	String name = "Jack Parker";
	name = name.toLowerCase();
    System.out.println(name);
	
	
	String name = "Harry";
	name = name.replace("Harry" , "sarada");
	System.out.println("Dear" + name + "Pokhrel");
	
	
//	Scanner sc = new Scanner(System.in);
//	
//	System.out.println("Enter your age");
//	int a = sc.nextInt();
//	
//	if( a > 18) {
//		System.out.println("you can drive");
//		
//	} else {
//		System.out.println("you can not drive");
//	}
	
	
	
//	Scanner sc = new Scanner (System.in);
//	
//	System.out.println ("Enter a website name");
//	String website = sc.next();
//	
//	if (website.endsWith(".com")) {
//		System.out.println("this is commercial website");
//		
//	} else if (website.endsWith(".es")) {
//	System.out.println("this is spanish website");
//	
//		} else {
//			System.out.println("this is not a website");
//		}
	
	
	
//	int i = 100;
//	while (i <= 200) {
//		System.out.println(i);
//		i++;
//	}
    
      
//	int i = 10;
//	do {
//		System.out.println(i);
//		i++;
//	}while(i < 5);
		
	
	
//	for (int i=5; i>0; i++) {
//		System.out.println(i);
//	}
	
	
	//n numbers in reverse using for loops 
//	 Scanner scanner = new Scanner(System.in);
//
//     System.out.print("Enter a number: ");
//     int n = scanner.nextInt();
//
//     for (int i = n; i >= 1; i--) {
//         System.out.println(i);
//     }
//		
 * 
 * 
 * 
 */
//	 int sum = 0;
//     int i = 0;
//     int n = 5;
//     while (i<n) {
//         sum = sum +(2* i);
//         i++;
//     }
//     System.out.println("sum of even number is :");
//     System.out.println(sum);
	
	
	
//	int a = 1;
//	int b = 2;
//	int suma = a + b;
//	
//	System.out.println("La suma de los dos numeros son :" + suma);
//	
	
	
	
	// factorial de un numero
//	int n = 5;
//	int factorial = 1;
//	
	
	
//	for (int i = 1; i <=n; i++) {
//		factorial *= i;
//      System.out.println("El factorial de 5 es:" + factorial);
		
//	}

	
	
//	int n =10;
//	int factorial = 1;
//	
//	for (int i = 1; i<=10; i++) {
//	factorial *= i;
//	System.out.println("El factorial de 10 es:" + factorial);
//	
//	}
	
	
	
//	float ancho = 5.0f;
//	float alto = 2.0f;
	
//	float area = ancho * alto ;
//	System.out.println("El area de un rectangulo es:" + area);

	
	
//	int celsius = 20;
//	int F = (celsius * 9/5) + 32;
//	System.out.println("El grado celsius en fahrenheit es:" + F);

	
	
//	int radio = 5;
//	
//	double perimetro =( Math.PI * radio );
//	System.out.println("El perimetro de un circuloes:" + perimetro);

	
	
//	int a = 5;
//	int b = 10;
//	
//	System.out.println("Antes de intercambio a :" + a);
//	System.out.println("Antes de intercambio b :" + b);
//	
//	a = a +b ;
//	b = a-b;
//	a = a-b;
//	System.out.println("Despues de intercambio a :" + a);
//	System.out.println("Despues de intercambio b :" + b);
	
	
	
//	int a = 5;
//	int b = 10;
//	int c = 15;
//	int promedio = (a + b+ c)/3;
//	System.out.println("El promedio de tres numeros es:" + promedio);
	
	
	
//	boolean a = true;
//	boolean b = false;
//	
//	boolean resultado1 = a && b ;
//	System.out.println("a AND b: " + resultado1);
//	
//	boolean resultado2 = a || b ;
//	System.out.println("a OR b: " + resultado2);
//	
//	boolean resultado3 = !a ;
//	System.out.println("a: " + resultado3);
//	
//	boolean resultado4 = !b ;
//	System.out.println("b: " + resultado4);
	
	
	
//	String nombre = "sarada";
//	String apellido = "pokhrel";
//	int edad = 20;
	
//	System.out.println("Mi nombre es " + nombre + " " +  apellido + " y tengo " + edad + " años ");

	
	
//	float precio = 20.0f;
//	float porcentaje = 5.0f;
//	
//	float preciofinal = precio / (1 + porcentaje);
//	System.out.println("El precio final es:" + preciofinal);
	
	
	
//	Scanner sc = new Scanner(System.in);
//	
//	System.out.println("Escribir un numero entero:");
//	int num = sc.nextInt();
//	
//	if (num % 2 == 0) {
//		System.out.println("El numero es par");
//	}else {
//		System.out.println("El numero es impar");
//	}
	
	
	
//	Scanner sc = new Scanner(System.in);
//	
//	System.out.println("Escribir el primer numero");
//	int num1 = sc.nextInt();
//	
//	System.out.println("Escribir el segundo numero");
//	int num2 = sc.nextInt();
//	
//	System.out.println("Escribir el tercer numero");
//	int num3 = sc.nextInt();
//	
//	if (num1 == num2 && num2 == num3) {
//		System.out.println("Todos son iguales");
//		
//	   }else if (num1 >= num2 && num1 >= num3) {
//			System.out.println("El mayor numero es:" + num1);
//		}else if (num2 >= num1 && num2>= num3) {
//				System.out.println("El mayor numero es:" + num2);
//			
//		} else{
//			System.out.println("El mayor numero es:" + num3);
//		}
//	
//		
//		}	
//      {
	
	
	
	
//	Scanner sc = new Scanner(System.in);
//	
//	System.out.println("Escribir el numero desde 0 a 100");
//	int puntuacion = sc.nextInt();
//	
//	if (puntuacion>=90) {
//		System.out.println("A");
//		
//	}else if (puntuacion>=80) {
//			System.out.println("B");
//			
//	}else if (puntuacion>=70) {
//		System.out.println("C");
//		
//	}else if (puntuacion>=60) {
//		System.out.println("D");
//		
//	}else {
//		System.out.println("E");
//		
//	}
	
	
	
//	for (int i = 1; i<=10; i++) {
//	System.out.println(i);
//	}
	
	
	
//	int suma = 0;
//	for (int i=1; i<=100; i++) {
//		suma += i;
//		System.out.println("La suma de los numeros son:" + suma);
//	}
	
	
//	int n =5;
//	for (int i=1; i<=10; i++) {
//		System.out.println(n + "x" + i + " = " + (n*i));
//		
//	}
	
	
//	Scanner sc = new Scanner(System.in);
//	
//	System.out.println("Escribir un numero:");
//	int i = sc.nextInt();
//	
//	int contador = 0;
//	while(i >= 0) {
//		i /= 10;
//		contador++;
//	}
//		System.out.println("El  numero tiene : " + contador);
     
	
	
	
//   int suma = 0;
//   for (int i =1; i<=100; i++) {
//	   if (i % 2 == 0) {
//		   suma += i;
//		   System.out.println("La suma de los numeros pares desde 1 a 100 es:" + suma);
//	   }
//   }
	
	
	
//	for (int i=1; i<=100; i++ ) {
//	System.out.println(i);
//	}
	
	
	//suma de los numeros 1 a 10
//	int n =10;
//	int suma = 0;
//	for (int i=1; i<=10; i++) {
//		suma += i;
//		System.out.println("La suma de los numeros desde 0 a 10 es:" + suma);
//	}
	
	
	
//	for (int i = 1; i<=50; i++) {
//		if (i % 2 == 0) {
//			System.out.println(i);
//		}
//	}
	
	
	
           //  4.factorial de un numero
	
//	Scanner sc = new Scanner(System.in);
//	System.out.println("Escribir un numero entero positivo:");
//	int numero = sc.nextInt();
//	
//	int factorial = 1;
//	for (int i =1; i<= numero; i++) {
//		factorial *= i;
//		System.out.println("El factorial de un numero es:" + factorial);
//	}
	     
	
	
	  // 5. multiplicacion de un numero
	
//	Scanner sc = new Scanner (System.in);
//	System.out.println("Escribir un numero entero:");
//	int numero = sc.nextInt();
//	
//	for (int i = 1; i<=10; i++) {
//		
//	System.out.println(numero + " X " + i + " = " + (numero * i));
//	}
	
	
	// 6.contar digitos
	
//	Scanner sc = new Scanner (System.in);
//	System.out.println("Escribir un numero entero");
//	int num = sc.nextInt();
//	
//	int contador =0;
//	while (num > 0) {
//		num /= 10;
//	contador++;
//	}
//	System.out.println("El contador es:" + contador);
	
	         
	       //7. Numeros primos
	
//		  for (int num = 2; num <= 100; num++) {
//	          boolean esPrimo = true;  // Asumimos que el número es primo
//
//	          // Comprobar si el número es divisible por algún número entre 2 y el número - 1
//	          for (int i = 2; i < num; i++) {
//	              if (num % i == 0) {  // Si el número es divisible, no es primo
//	                  esPrimo = false;
//	                  break;  // Salimos del bucle porque no es primo
//	              }
//	          }
//
//	          // Si es primo, lo imprimimos
//	          if (esPrimo) {
//	              System.out.print(num + " ");
//	          }
//	      }
	
	          // 8. numeros invertido
	
	

	// 9.suma de los numeros pares y impares ( wrong)
//	Scanner sc = new Scanner (System.in);
//	System.out.println("Escribir un numero entero");
//	int num = sc.nextInt();  
//	
//	int sumaPares = 0;
//	int sumaImpares = 0;
//	
//	for (int i = 1; i <= 10; i++) {
//		System.out.println(i);
//		
//		if (num % 2 == 0) {
//			sumaPares += num;
//			
//		}else {
//			sumaImpares += num;
//		}
//		
//	}
//	System.out.println("la suma de los numeros pares es:" + sumaPares);
//	System.out.println("la suma de los numeros impares es:" + sumaImpares);
	

	           //from chat gpt
	
//       Scanner scanner = new Scanner(System.in);
//        
//        // Inicializar las variables para las sumas
//        int sumaPares = 0;
//        int sumaImpares = 0;
//        
//        // Solicitar 10 números al usuario
//        for (int i = 1; i <= 10; i++) {
//            System.out.print("Ingresa el número " + i + ": ");
//            int numero = scanner.nextInt();
//            
//            // Verificar si el número es par o impar
//            if (numero % 2 == 0) {
//                sumaPares += numero;  // Si el número es par, sumarlo a sumaPares
//            } else {
//                sumaImpares += numero;  // Si el número es impar, sumarlo a sumaImpare
                // Mostrar los resultados
	
       /* System.out.println("La suma d
                 los números pares es: " + sumaPares);
         scanner.close();
    }
     }
     */

	     //  Suma de los dígitos de un número
	
	/* Scanner scanner = new Scanner(System.in);

    System.out.print("Ingresa un número entero: ");
    int numero = scanner.nextInt();

   int suma = 0;
    while (numero != 0) {
        int digito = numero % 10;
        suma += digito;
       numero = numero / 10;
    }

    System.out.println("La suma de los dígitos es: " + suma);
	*/
	

}
}
	
	
	

