package MainJava;

public class Examen3 {

	public static int[] encontrarMaximoMinimo(int[] arreglo) {
		int max = arreglo[0];
		int min = arreglo[0];
		for (int i = 1; i < arreglo.length; i++) {
		if (arreglo[i] > max)
		max = arreglo[i];
		if (arreglo[i] < min)
		min = arreglo[i];
		}
		return new int[] { max, min };
		}

		// Ejemplo de uso:
		public static void main(String[] args) {
		int[] arreglo = { 3, 7, 2, 8, 4 };
		int[] resultado = encontrarMaximoMinimo(arreglo);
		System.out.println("Máximo: " + resultado[0]); // Máximo esperado: 8
		System.out.println("Mínimo: " + resultado[1]); // Mínimo esperado: 2
		}

		}

