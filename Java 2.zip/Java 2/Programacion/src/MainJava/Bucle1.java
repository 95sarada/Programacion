package MainJava;

public class Bucle1 {
	//Imprimir números del 1 al 100
	public class Main {
	    public static void main(String[] args) {
	        for (int i = 1; i <= 100; i++) {
	            System.out.println(i);
	        }
	    }
	}

}
