package MainJava;

	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Scanner;

	//Invertir los elementos de un ArrayList
	public class Arraylist9 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Ingresa números enteros (escribe un número negativo para terminar):");
	        while (true) {
	            int numero = scanner.nextInt();
	            if (numero < 0) {
	                break;
	            }
	            numeros.add(numero);
	        }

	        Collections.reverse(numeros);
	        System.out.println("ArrayList en orden inverso: " + numeros);
	    }
	}


