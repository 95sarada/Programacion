package MainJava;
	import java.util.ArrayList;
	import java.util.Scanner;

	// Sumar todos los elementos de un ArrayList
	public class Arraylist8 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Ingresa números enteros (ingresa un valor no numérico para terminar):");
	        while (scanner.hasNextInt()) {
	            numeros.add(scanner.nextInt());
	        }

	        int suma = 0;
	        for (int num : numeros) {
	            suma += num;
	        }

	        System.out.println("La suma de los elementos es: " + suma);
	    }
	}


