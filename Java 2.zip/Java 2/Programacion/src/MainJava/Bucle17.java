package MainJava;
import java.util.Scanner;
//17. Sumar los números entre dos valores
public class Bucle17 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa el primer número A: ");
        int A = scanner.nextInt();
        System.out.print("Ingresa el segundo número B: ");
        int B = scanner.nextInt();
        int suma = 0;

        for (int i = A; i <= B; i++) {
            suma += i;
        }

        System.out.println("La suma de los números entre " + A + " y " + B + " es: " + suma);
    }
}
