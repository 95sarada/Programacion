package MainJava;
import java.util.Scanner;
public class Bucle9 {
	//9. Suma de números pares y impares
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sumaPares = 0, sumaImpares = 0;

        for (int i = 0; i < 10; i++) {
            System.out.print("Ingresa un número: ");
            int numero = scanner.nextInt();

            if (numero % 2 == 0) {
                sumaPares += numero;
            } else {
                sumaImpares += numero;
            }
        }

        System.out.println("La suma de los números pares es: " + sumaPares);
        System.out.println("La suma de los números impares es: " + sumaImpares);
    }
}
