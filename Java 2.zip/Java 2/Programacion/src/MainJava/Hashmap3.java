package MainJava;
import java.util.HashMap;
public class Hashmap3 {
	public static void main(String[] args) {
		
		HashMap <String, Integer> people = new HashMap<String, Integer> ();
		
		people.put("Juan", 25);
		people.put("Maria", 20);
		people.put("Jose", 30);
		
		for (String i : people.keySet()) {
			System.out.println( i + "Edad" + people.get(i) );
		}
	}

}
