package MainJava;

	//ordenar arrays en orden ascendente
	import java.util.Arrays;
	import java.util.Collections;

	public class Array3 {
	    public static void main(String[] args) {
	        
	        Integer[] numeros = {5, 2, 8, 4, 1, 3, 7, 6};

	        
	        System.out.println("Array original: " + Arrays.toString(numeros));

	     
	        Arrays.sort(numeros, Collections.reverseOrder());

	      
	        System.out.println("Array ordenado en orden descendente: " + Arrays.toString(numeros));
	    }
	}
