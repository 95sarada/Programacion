package MainJava;

	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Scanner;
	//Ordenar un ArrayList
	
	public class Arraylist5 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.print("Ingresa un número (negativo para terminar): ");
	            int numero = scanner.nextInt();
	            if (numero < 0) {
	                break;
	            }
	            numeros.add(numero);
	        }

	        Collections.sort(numeros);
	        System.out.println("Lista ordenada: " + numeros);
	    }
	}


