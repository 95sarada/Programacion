package MainJava;
import java.util.HashMap;
public class Hashmap2 {
public static void main(String[] args) {
	
	HashMap<String, Integer> map = new HashMap<>();
	
	map.put("Juan", 20);
	map.put("Ana", 25);
	map.put("Carlos", 30);
	System.out.println("La edad de Ana es:" + map.get("Ana"));
	
	if (map.containsKey("Carlos")){
		System.out.println("Carlos esta en la mapa.");	
	}
	
	// 2 methods
	//if you only want the keys 
	for (String i : map.keySet()) {
		System.out.println(i);
	}
	
		//if you only want the values 
	System.out.println("values");
		for (int i : map.values()) {
			System.out.println(i);
		}
	
	//or 
	
	//another method to get both
	for (String i : map.keySet()) {
		System.out.println( i + "Edad es:" + map.get(i));
	}
	
	//to remove one 
   map.remove("Ana");
	
	//to clear all
   map.clear();
	
	//to find out the size
	System.out.println(" The size is:" + map.size());
}
}
