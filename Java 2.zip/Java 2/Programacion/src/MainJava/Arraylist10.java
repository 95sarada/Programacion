package MainJava;

	import java.util.ArrayList;
	import java.util.Scanner;

//	Filtrar números pares e impares
	public class Arraylist10 {
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        ArrayList<Integer> pares = new ArrayList<>();
	        ArrayList<Integer> impares = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Ingresa números enteros (escribe un número negativo para terminar):");
	        while (true) {
	            int numero = scanner.nextInt();
	            if (numero < 0) {
	                break;
	            }
	            numeros.add(numero);
	        }

	        for (int num : numeros) {
	            if (num % 2 == 0) {
	                pares.add(num);
	            } else {
	                impares.add(num);
	            }
	        }

	        System.out.println("Números pares: " + pares);
	        System.out.println("Números impares: " + impares);
	    }
	}


