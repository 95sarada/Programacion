package MainJava;

	import java.util.ArrayList;
	import java.util.Scanner;

	public class Arraylist1 {
		
		//creacion de un arraylist
	    public static void main(String[] args) {
	        ArrayList<Integer> numeros = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        for (int i = 0; i < 5; i++) {
	            System.out.print("Ingresa un número entero: ");
	            numeros.add(scanner.nextInt());
	        }

	        System.out.println("Contenido del ArrayList: " + numeros);
	    }
	}

	

